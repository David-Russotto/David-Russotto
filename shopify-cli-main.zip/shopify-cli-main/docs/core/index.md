---
title: Shopify CLI core commands
redirect_to: https://shopify.dev/tools/cli/reference
---
