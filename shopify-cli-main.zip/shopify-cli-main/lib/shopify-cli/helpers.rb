module ShopifyCli
  module Helpers
    autoload :Haikunator, "shopify-cli/helpers/haikunator"
  end
end
