module ShopifyCli
  module Resources
    autoload :EnvFile, "shopify-cli/resources/env_file"
  end
end
